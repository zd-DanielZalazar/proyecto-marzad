package com.sga.marzad.viewmodel;

public enum ResultadoInscripcion {
    OK,
    YA_INSCRIPTO,
    CORRELATIVA_NO_APROBADA,
    ERROR_BD
}
